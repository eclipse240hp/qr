// the 'Database' of badge infos
var badgeInfos = [
	{
		firstName	: 'Mike',
		lastName	: 'Newton',
		role            : 'industry',
		markerId	: 0,
		avatar	        : '/examples/contact-sharing-in-ar/avatars/avatar-0.jpg',
	},
	{
		firstName	: 'Adam',
		lastName	: 'Huxley',
		role            : 'designer',
		markerId	: 236,
		avatar	        : '/examples/contact-sharing-in-ar/avatars/avatar-236.jpg',
	},
	{
		firstName	: 'Albert',
		lastName	: 'Walton',
		role            : 'corporate',
		markerId	: 265,
		avatar	        : '/examples/contact-sharing-in-ar/avatars/avatar-265.jpg',
	},
]
